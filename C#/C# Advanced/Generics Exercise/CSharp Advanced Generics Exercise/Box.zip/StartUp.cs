﻿namespace GenericBox
{
    using System;
    using System.Linq;

    public class StartUp
    {
        private static void Main(string[] args)
        {
            var n = int.Parse(Console.ReadLine());
            var box = new Box<string>();

            for (int i = 0; i < n; i++)
            {
                var input = Console.ReadLine();
                box.Add(input);
            }

            var swapArgs = Console.ReadLine()
                .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray();

            var firstIndex = swapArgs[0];
            var secondIndex = swapArgs[1];

            box.Swap(firstIndex, secondIndex);

            Console.WriteLine(box);
        }
    }
}