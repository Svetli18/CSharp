﻿namespace _01.RedBlackTree
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public enum Color
    {
        Red,
        Black
    }
}
