﻿namespace Exam.TaskManager
{
    using System;
    using Exam.TaskManager;

    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
