﻿namespace Exam.Expressionist
{
    public enum ExpressionType
    {
        Value,
        Operator
    }
}
