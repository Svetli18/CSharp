namespace _01.DogVet
{
    public enum Breed
    {
        Doberman,
        Poodle,
        Bulldog,
        CockerSpaniel,
        GermanShepherd
    }
}