﻿
namespace Exam.MobileX
{
    using System;
    using System.Collections.Generic;

    public class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
