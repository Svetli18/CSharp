﻿namespace Kubernetes
{
    public interface IController<T>
    {
    }
}