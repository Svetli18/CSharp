﻿namespace Farm
{
    using System;

    public class StartUp
    {
        static void Main(string[] args)
        {
            MyConsole myConsole = new MyConsole();

            Dog dog = new Dog();

            myConsole.Write(dog.Bark());
            myConsole.Write(dog.Eat());

            Puppy puppy = new Puppy();

            myConsole.Write(puppy.Eat());
            myConsole.Write(puppy.Bark());
            myConsole.Write(puppy.Weep());

            Cat cat = new Cat();

            myConsole.Write(cat.Eat());
            myConsole.Write(cat.Meow());
        }
    }
}

