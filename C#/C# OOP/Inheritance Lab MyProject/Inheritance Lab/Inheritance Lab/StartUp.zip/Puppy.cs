﻿namespace Farm
{
    public class Puppy : Dog
    {
        public string Weep()
        {
            return "weeping...";
        }
    }
}
