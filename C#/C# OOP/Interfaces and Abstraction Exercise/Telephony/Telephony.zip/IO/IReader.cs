﻿namespace Telephony
{
    public interface IReader
    {
        string ReadLine();
    }
}
