﻿namespace Telephony
{
    public interface IEngine
    {
        void Run();
    }
}
