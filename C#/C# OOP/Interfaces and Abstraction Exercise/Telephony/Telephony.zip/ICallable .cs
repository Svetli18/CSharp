﻿namespace Telephony
{
    public interface ICallable
    {
        string Calling(string number);
    }
}
