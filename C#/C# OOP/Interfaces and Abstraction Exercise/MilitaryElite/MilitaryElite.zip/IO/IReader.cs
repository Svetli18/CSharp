﻿namespace MilitaryElite.IO
{
    public interface IReader
    {
        string ReadLine();
    }
}
