﻿namespace MilitaryElite.Enumarations
{
    public enum State
    {
        inProgress = 1,
        finished = 2,
    }
}
