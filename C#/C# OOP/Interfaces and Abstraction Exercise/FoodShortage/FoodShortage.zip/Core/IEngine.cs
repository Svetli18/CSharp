﻿namespace FoodShortage.Core
{
    public interface IEngine
    {
        void Run();
    }
}
