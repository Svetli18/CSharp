﻿namespace FoodShortage.Contracts
{
    public interface IRebel : IPerson
    {
        string Group { get; }
    }
}
