﻿namespace FoodShortage.IO
{
    public interface IReader
    {
        string ReadLine();
    }
}
