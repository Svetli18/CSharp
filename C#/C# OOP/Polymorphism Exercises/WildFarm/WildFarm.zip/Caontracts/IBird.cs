﻿namespace WildFarm.Caontracts
{
    public interface IBird : IAnimal
    {
        double WingSize { get; }
    }
}
