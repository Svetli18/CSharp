﻿namespace WildFarm.Caontracts
{
    public interface IFood
    {
        int Quantity { get; }
    }
}
