﻿namespace WildFarm.Caontracts
{
    public interface IMammal : IAnimal
    {
        string LivingRegion { get; }
    }
}
