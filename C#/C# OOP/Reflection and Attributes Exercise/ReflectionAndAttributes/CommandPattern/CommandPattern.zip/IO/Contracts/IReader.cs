﻿namespace CommandPattern.IO.Contracts
{
    using System;

    public interface IReader
    {
        string ReadLine();
    }
}
