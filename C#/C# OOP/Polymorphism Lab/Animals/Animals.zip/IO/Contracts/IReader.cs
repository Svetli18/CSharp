﻿namespace Operations.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
