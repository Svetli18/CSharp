﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemos.Animals
{
    public class Dog : Animal
    {
        public void Bark()
        {
            Console.WriteLine("Bau bau...");
        }
    }
}
